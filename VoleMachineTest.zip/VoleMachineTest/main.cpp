#include <QApplication>
#include "volemachinetest.h"
#include "A1_T4_S5_S19_20231134_20231116_20231042.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    VoleMachineTest window;
    window.show();
    return app.exec();
}
