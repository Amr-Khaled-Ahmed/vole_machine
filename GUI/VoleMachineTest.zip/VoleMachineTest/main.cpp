#include <QApplication>
#include "volemachinetest.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    VoleMachineTest window;
    window.show();
    return app.exec();
}
