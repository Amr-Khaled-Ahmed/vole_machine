#include "volemachinetest.h"
#include "ui_volemachinetest.h"
#include <QString>
#include <QStringList>
#include <QRegularExpression> // Include this header

VoleMachineTest::VoleMachineTest(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::VoleMachineTest)
{
    ui->setupUi(this);
    registers.resize(16); // 16 registers
    registers.fill(0); // Initialize all registers to 0
    updateRegistersDisplay(); // Initial update of register display
}

VoleMachineTest::~VoleMachineTest()
{
    delete ui;
}

void VoleMachineTest::on_executeButton_clicked()
{
    // Get the text from the input field
    QString codes = ui->codeInput->toPlainText(); // Updated line

    // Clear previous register values (optional)
    registers.fill(0);

    // Prepare to store the current number being processed
    QString currentCode;
    for (const QChar &ch : codes) {
        // Check if the character is whitespace or a comma
        if (ch.isSpace() || ch == ',') {
            if (!currentCode.isEmpty()) {
                // Convert currentCode to an integer and store it
                uint16_t machineCode = static_cast<uint16_t>(currentCode.toInt(nullptr, 16)); // Convert to 16-bit integer

                // Find the first empty register and store the code
                for (int i = 0; i < registers.size(); ++i) {
                    if (registers[i] == 0) {
                        registers[i] = machineCode; // Store the code in the register
                        break; // Exit loop after storing
                    }
                }

                // Clear the current code for the next number
                currentCode.clear();
            }
        } else {
            // Append character to currentCode
            currentCode.append(ch);
        }
    }

    // Process the last code if any
    if (!currentCode.isEmpty()) {
        uint16_t machineCode = static_cast<uint16_t>(currentCode.toInt(nullptr, 16));
        for (int i = 0; i < registers.size(); ++i) {
            if (registers[i] == 0) {
                registers[i] = machineCode;
                break;
            }
        }
    }

    // Execute the loaded machine codes
    executeCodes();

    // Call updateRegistersDisplay to refresh the UI
    updateRegistersDisplay();
}

void VoleMachineTest::executeCodes()
{
    for (const auto &code : registers) {
        if (code == 0) continue; // Skip empty registers

        uint8_t opcode = (code >> 12) & 0xF; // Get the opcode (first 4 bits)
        uint8_t r = (code >> 8) & 0xF;       // Get the first register (next 4 bits)
        uint8_t s = (code >> 4) & 0xF;       // Get the second register (next 4 bits)
        uint8_t t = code & 0xF;               // Get the third register (last 4 bits)

        switch (opcode) {
        case 0x2: // LOAD
            registers[r] = code & 0xFF; // Load the last byte into register R
            break;
        case 0x4: // MOVE
            registers[s] = registers[r]; // Move R to S
            break;
        case 0x5: // ADD (Two's complement)
            registers[r] = static_cast<int16_t>(registers[s]) + static_cast<int16_t>(registers[t]);
            break;
        case 0x6: // ADD (Floating-point)
            registers[r] = static_cast<float>(registers[s]) + static_cast<float>(registers[t]);
            break;
        case 0x7: // OR
            registers[r] = registers[s] | registers[t];
            break;
        case 0x8: // AND
            registers[r] = registers[s] & registers[t];
            break;
        case 0x9: // EXCLUSIVE OR
            registers[r] = registers[s] ^ registers[t];
            break;
        default:
            // Handle unknown opcode
            break;
        }
    }
}

void VoleMachineTest::updateRegistersDisplay()
{
    ui->register0Label->setText(QString("R0: 0x%1").arg(registers[0], 4, 16, QLatin1Char('0'))); // Update register labels
    ui->register1Label->setText(QString("R1: 0x%1").arg(registers[1], 4, 16, QLatin1Char('0')));
    ui->register2Label->setText(QString("R2: 0x%1").arg(registers[2], 4, 16, QLatin1Char('0')));
    ui->register3Label->setText(QString("R3: 0x%1").arg(registers[3], 4, 16, QLatin1Char('0')));
    ui->register4Label->setText(QString("R4: 0x%1").arg(registers[4], 4, 16, QLatin1Char('0')));
    ui->register5Label->setText(QString("R5: 0x%1").arg(registers[5], 4, 16, QLatin1Char('0')));
    ui->register6Label->setText(QString("R6: 0x%1").arg(registers[6], 4, 16, QLatin1Char('0')));
    ui->register7Label->setText(QString("R7: 0x%1").arg(registers[7], 4, 16, QLatin1Char('0')));
    ui->register8Label->setText(QString("R8: 0x%1").arg(registers[8], 4, 16, QLatin1Char('0')));
    ui->register9Label->setText(QString("R9: 0x%1").arg(registers[9], 4, 16, QLatin1Char('0')));
    ui->register10Label->setText(QString("R10: 0x%1").arg(registers[10], 4, 16, QLatin1Char('0')));
    ui->register11Label->setText(QString("R11: 0x%1").arg(registers[11], 4, 16, QLatin1Char('0')));
    ui->register12Label->setText(QString("R12: 0x%1").arg(registers[12], 4, 16, QLatin1Char('0')));
    ui->register13Label->setText(QString("R13: 0x%1").arg(registers[13], 4, 16, QLatin1Char('0')));
    ui->register14Label->setText(QString("R14: 0x%1").arg(registers[14], 4, 16, QLatin1Char('0')));
    ui->register15Label->setText(QString("R15: 0x%1").arg(registers[15], 4, 16, QLatin1Char('0')));
}
