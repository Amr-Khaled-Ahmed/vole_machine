#ifndef VOLEMACHINETEST_H
#define VOLEMACHINETEST_H

#include <QWidget>
#include <QString>
#include <QVector>

QT_BEGIN_NAMESPACE
namespace Ui { class VoleMachineTest; }
QT_END_NAMESPACE

class VoleMachineTest : public QWidget
{
    Q_OBJECT

public:
    VoleMachineTest(QWidget *parent = nullptr);
    ~VoleMachineTest();

private slots:
    void on_executeButton_clicked(); // Slot for button click
    void executeCodes(); // Declare the executeCodes function


private:
    Ui::VoleMachineTest *ui;
    QVector<uint16_t> registers; // Array to hold 16 registers (2 bytes each)
    void updateRegistersDisplay(); // Method to update the display of registers
};

#endif // VOLEMACHINETEST_H
